﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class DepositSavings : Form
    {
        public DepositSavings()
        {
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void txtDepositSavings_TextChanged(object sender, EventArgs e)
        {
            int value;
            if (int.TryParse(txtDepositSavings.Text, out value))
            {
                if (value < 0 || value > 9999)
                {
                    MessageBox.Show("Deposit amount exceeds the limit of 9999. Please enter a valid amount.", "Limit Exceeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDepositSavings.Text = "";
                }
            }
            else
            {
                txtDepositSavings.Text = "";
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double depositAmount;
            if (double.TryParse(txtDepositSavings.Text, out depositAmount))
            {
                AccountInfo.savingsAmount += depositAmount;
                txtDepositSavings.Text = "";
                depositSavingsrecepit receiptForm = new depositSavingsrecepit(depositAmount);
                this.Hide();
                receiptForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private void DepositSavings_Load(object sender, EventArgs e)
        {

        }
    }
}
