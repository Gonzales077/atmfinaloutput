﻿namespace atmsystem
{
    partial class DepositSavings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepositSavings));
            confirmBtn = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            txtDepositSavings = new Guna.UI2.WinForms.Guna2TextBox();
            CancelBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // confirmBtn
            // 
            confirmBtn.BackColor = Color.Transparent;
            confirmBtn.BorderColor = Color.DarkSlateGray;
            confirmBtn.BorderRadius = 15;
            confirmBtn.BorderThickness = 2;
            confirmBtn.CustomizableEdges = customizableEdges1;
            confirmBtn.DisabledState.BorderColor = Color.DarkGray;
            confirmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            confirmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            confirmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            confirmBtn.FillColor = Color.Teal;
            confirmBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            confirmBtn.ForeColor = Color.White;
            confirmBtn.Location = new Point(434, 329);
            confirmBtn.Name = "confirmBtn";
            confirmBtn.PressedColor = Color.DarkSlateGray;
            confirmBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            confirmBtn.Size = new Size(141, 45);
            confirmBtn.TabIndex = 18;
            confirmBtn.Text = "Confirm";
            confirmBtn.Click += confirmBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Teal;
            label1.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(434, 129);
            label1.Name = "label1";
            label1.Size = new Size(162, 21);
            label1.TabIndex = 17;
            label1.Text = "Enter Amount here:";
            // 
            // txtDepositSavings
            // 
            txtDepositSavings.BackColor = Color.Transparent;
            txtDepositSavings.BorderColor = Color.DarkSlateGray;
            txtDepositSavings.BorderRadius = 15;
            txtDepositSavings.BorderThickness = 2;
            txtDepositSavings.CustomizableEdges = customizableEdges3;
            txtDepositSavings.DefaultText = "";
            txtDepositSavings.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDepositSavings.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDepositSavings.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDepositSavings.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDepositSavings.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositSavings.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDepositSavings.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositSavings.Location = new Point(419, 153);
            txtDepositSavings.Margin = new Padding(4, 3, 4, 3);
            txtDepositSavings.Name = "txtDepositSavings";
            txtDepositSavings.PasswordChar = '\0';
            txtDepositSavings.PlaceholderText = "Enter Amount";
            txtDepositSavings.SelectedText = "";
            txtDepositSavings.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtDepositSavings.Size = new Size(344, 55);
            txtDepositSavings.TabIndex = 16;
            txtDepositSavings.TextChanged += txtDepositSavings_TextChanged;
            // 
            // CancelBtn
            // 
            CancelBtn.BackColor = Color.Transparent;
            CancelBtn.BorderColor = Color.DarkSlateGray;
            CancelBtn.BorderRadius = 15;
            CancelBtn.BorderThickness = 2;
            CancelBtn.CustomizableEdges = customizableEdges5;
            CancelBtn.DisabledState.BorderColor = Color.DarkGray;
            CancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            CancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CancelBtn.FillColor = Color.Teal;
            CancelBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CancelBtn.ForeColor = Color.White;
            CancelBtn.Location = new Point(607, 329);
            CancelBtn.Name = "CancelBtn";
            CancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            CancelBtn.Size = new Size(141, 45);
            CancelBtn.TabIndex = 20;
            CancelBtn.Text = "Cancel";
            CancelBtn.Click += CancelBtn_Click;
            // 
            // DepositSavings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(845, 425);
            Controls.Add(CancelBtn);
            Controls.Add(confirmBtn);
            Controls.Add(label1);
            Controls.Add(txtDepositSavings);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DepositSavings";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DepositSavings";
            Load += DepositSavings_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button confirmBtn;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtDepositSavings;
        private Guna.UI2.WinForms.Guna2Button CancelBtn;
    }
}