﻿namespace atmsystem
{
    partial class WithdrawCheque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WithdrawCheque));
            chequeAmount = new Guna.UI2.WinForms.Guna2TextBox();
            confirmBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            SuspendLayout();
            // 
            // chequeAmount
            // 
            chequeAmount.BackColor = Color.Transparent;
            chequeAmount.BorderColor = Color.DarkSlateGray;
            chequeAmount.BorderRadius = 15;
            chequeAmount.BorderThickness = 2;
            chequeAmount.CustomizableEdges = customizableEdges1;
            chequeAmount.DefaultText = "";
            chequeAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            chequeAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            chequeAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            chequeAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            chequeAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            chequeAmount.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chequeAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            chequeAmount.Location = new Point(422, 167);
            chequeAmount.Margin = new Padding(4, 3, 4, 3);
            chequeAmount.Name = "chequeAmount";
            chequeAmount.PasswordChar = '\0';
            chequeAmount.PlaceholderText = "Enter Amount";
            chequeAmount.SelectedText = "";
            chequeAmount.ShadowDecoration.CustomizableEdges = customizableEdges2;
            chequeAmount.Size = new Size(344, 55);
            chequeAmount.TabIndex = 5;
            chequeAmount.TextChanged += chequeAmount_TextChanged;
            // 
            // confirmBtn
            // 
            confirmBtn.BackColor = Color.Transparent;
            confirmBtn.BorderColor = Color.DarkSlateGray;
            confirmBtn.BorderRadius = 15;
            confirmBtn.BorderThickness = 2;
            confirmBtn.CustomizableEdges = customizableEdges3;
            confirmBtn.DisabledState.BorderColor = Color.DarkGray;
            confirmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            confirmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            confirmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            confirmBtn.FillColor = Color.Teal;
            confirmBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            confirmBtn.ForeColor = Color.White;
            confirmBtn.Location = new Point(422, 329);
            confirmBtn.Name = "confirmBtn";
            confirmBtn.PressedColor = Color.DarkSlateGray;
            confirmBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            confirmBtn.Size = new Size(141, 45);
            confirmBtn.TabIndex = 7;
            confirmBtn.Text = "Confirm";
            confirmBtn.Click += confirmBtn_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.BackColor = Color.Transparent;
            guna2Button1.BorderColor = Color.DarkSlateGray;
            guna2Button1.BorderRadius = 15;
            guna2Button1.BorderThickness = 2;
            guna2Button1.CustomizableEdges = customizableEdges5;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.Teal;
            guna2Button1.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(625, 329);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button1.Size = new Size(141, 45);
            guna2Button1.TabIndex = 8;
            guna2Button1.Text = "Cancel";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Teal;
            guna2HtmlLabel1.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.Transparent;
            guna2HtmlLabel1.Location = new Point(422, 138);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(157, 23);
            guna2HtmlLabel1.TabIndex = 9;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // WithdrawCheque
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(845, 425);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(guna2Button1);
            Controls.Add(confirmBtn);
            Controls.Add(chequeAmount);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "WithdrawCheque";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "WithdrawCheque";
            Load += WithdrawCheque_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2TextBox chequeAmount;
        private Guna.UI2.WinForms.Guna2Button confirmBtn;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}