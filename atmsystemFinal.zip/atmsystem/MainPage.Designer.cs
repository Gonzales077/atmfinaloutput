﻿namespace atmsystem
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainPage));
            CheckBalBtn = new Guna.UI2.WinForms.Guna2Button();
            DepositBtn = new Guna.UI2.WinForms.Guna2Button();
            WithdrawBtn = new Guna.UI2.WinForms.Guna2Button();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // CheckBalBtn
            // 
            CheckBalBtn.BackColor = Color.Transparent;
            CheckBalBtn.BorderColor = Color.DarkSlateGray;
            CheckBalBtn.BorderRadius = 15;
            CheckBalBtn.BorderThickness = 2;
            CheckBalBtn.CustomizableEdges = customizableEdges1;
            CheckBalBtn.DisabledState.BorderColor = Color.DarkGray;
            CheckBalBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            CheckBalBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CheckBalBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CheckBalBtn.FillColor = Color.Teal;
            CheckBalBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CheckBalBtn.ForeColor = Color.White;
            CheckBalBtn.Location = new Point(479, 163);
            CheckBalBtn.Name = "CheckBalBtn";
            CheckBalBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            CheckBalBtn.Size = new Size(235, 48);
            CheckBalBtn.TabIndex = 5;
            CheckBalBtn.Text = "Check Balance";
            CheckBalBtn.Click += CheckBalBtn_Click;
            // 
            // DepositBtn
            // 
            DepositBtn.BackColor = Color.Transparent;
            DepositBtn.BorderColor = Color.DarkSlateGray;
            DepositBtn.BorderRadius = 15;
            DepositBtn.BorderThickness = 2;
            DepositBtn.CustomizableEdges = customizableEdges3;
            DepositBtn.DisabledState.BorderColor = Color.DarkGray;
            DepositBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            DepositBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            DepositBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            DepositBtn.FillColor = Color.Teal;
            DepositBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositBtn.ForeColor = Color.White;
            DepositBtn.Location = new Point(479, 256);
            DepositBtn.Name = "DepositBtn";
            DepositBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            DepositBtn.Size = new Size(235, 48);
            DepositBtn.TabIndex = 6;
            DepositBtn.Text = "Deposit";
            DepositBtn.Click += DepositBtn_Click;
            // 
            // WithdrawBtn
            // 
            WithdrawBtn.BackColor = Color.Transparent;
            WithdrawBtn.BorderColor = Color.DarkSlateGray;
            WithdrawBtn.BorderRadius = 15;
            WithdrawBtn.BorderThickness = 2;
            WithdrawBtn.CustomizableEdges = customizableEdges5;
            WithdrawBtn.DisabledState.BorderColor = Color.DarkGray;
            WithdrawBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            WithdrawBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            WithdrawBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            WithdrawBtn.FillColor = Color.Teal;
            WithdrawBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WithdrawBtn.ForeColor = Color.White;
            WithdrawBtn.Location = new Point(766, 163);
            WithdrawBtn.Name = "WithdrawBtn";
            WithdrawBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            WithdrawBtn.Size = new Size(235, 48);
            WithdrawBtn.TabIndex = 7;
            WithdrawBtn.Text = "Withdraw";
            WithdrawBtn.Click += WithdrawBtn_Click;
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges7;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(766, 256);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 8;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1064, 425);
            Controls.Add(cancelBtn);
            Controls.Add(WithdrawBtn);
            Controls.Add(DepositBtn);
            Controls.Add(CheckBalBtn);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainPage";
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button CheckBalBtn;
        private Guna.UI2.WinForms.Guna2Button DepositBtn;
        private Guna.UI2.WinForms.Guna2Button WithdrawBtn;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}