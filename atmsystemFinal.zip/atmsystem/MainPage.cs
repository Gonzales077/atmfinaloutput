﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            Form1 backtoLogin = new Form1();
            this.Hide();
            backtoLogin.Show();
        }

        private void CheckBalBtn_Click(object sender, EventArgs e)
        {
            CheckBalance checkbalSec = new CheckBalance();
            this.Hide();
            checkbalSec.Show();
        }

        private void WithdrawBtn_Click(object sender, EventArgs e)
        {
            WithdrawSec gotoWithdraw = new WithdrawSec();
            this.Hide();
            gotoWithdraw.Show();
        }

        private void DepositBtn_Click(object sender, EventArgs e)
        {
            DepositForm gotoDeposit = new DepositForm();
            this.Hide();
            gotoDeposit.Show();
        }
    }
}
