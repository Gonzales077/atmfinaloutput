﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class WithdrawSavings : Form
    {
        public WithdrawSavings()
        {
            InitializeComponent();
        }

        private void savingsAmount_TextChanged(object sender, EventArgs e)
        {
            double amount;
            if (!double.TryParse(savingsAmount.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out amount))
            {
                savingsAmount.Text = "";
                confirmBtn.Enabled = false;
            }
            else
            {
                if (amount > AccountInfo.savingsAmount)
                {
                    confirmBtn.Enabled = false;
                }
                else
                {
                    confirmBtn.Enabled = true;
                }
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double withdrawalAmount;
            if (double.TryParse(savingsAmount.Text, out withdrawalAmount))
            {
                if (withdrawalAmount <= AccountInfo.savingsAmount)
                {
                    AccountInfo.savingsAmount -= withdrawalAmount;
                    withdrawSavingsreceipt receipt = new withdrawSavingsreceipt(withdrawalAmount);
                    this.Hide();
                    receipt.Show();
                }
                else
                {
                    MessageBox.Show("Insufficient balance");
                }
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            WithdrawSec backtowithdrawSec = new WithdrawSec();
            this.Hide();
            backtowithdrawSec.Show();
        }
    }
}
