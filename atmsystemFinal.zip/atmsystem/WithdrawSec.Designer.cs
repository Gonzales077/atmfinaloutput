﻿namespace atmsystem
{
    partial class WithdrawSec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WithdrawSec));
            WithdrawSavingsBtn = new Guna.UI2.WinForms.Guna2Button();
            WithdrawChequeBtn = new Guna.UI2.WinForms.Guna2Button();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // WithdrawSavingsBtn
            // 
            WithdrawSavingsBtn.BackColor = Color.Transparent;
            WithdrawSavingsBtn.BorderColor = Color.DarkSlateGray;
            WithdrawSavingsBtn.BorderRadius = 15;
            WithdrawSavingsBtn.BorderThickness = 2;
            WithdrawSavingsBtn.CustomizableEdges = customizableEdges1;
            WithdrawSavingsBtn.DisabledState.BorderColor = Color.DarkGray;
            WithdrawSavingsBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            WithdrawSavingsBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            WithdrawSavingsBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            WithdrawSavingsBtn.FillColor = Color.Teal;
            WithdrawSavingsBtn.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            WithdrawSavingsBtn.ForeColor = Color.White;
            WithdrawSavingsBtn.Location = new Point(105, 481);
            WithdrawSavingsBtn.Name = "WithdrawSavingsBtn";
            WithdrawSavingsBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            WithdrawSavingsBtn.Size = new Size(235, 48);
            WithdrawSavingsBtn.TabIndex = 10;
            WithdrawSavingsBtn.Text = "Savings";
            WithdrawSavingsBtn.Click += WithdrawSavingsBtn_Click;
            // 
            // WithdrawChequeBtn
            // 
            WithdrawChequeBtn.BackColor = Color.Transparent;
            WithdrawChequeBtn.BorderColor = Color.DarkSlateGray;
            WithdrawChequeBtn.BorderRadius = 15;
            WithdrawChequeBtn.BorderThickness = 2;
            WithdrawChequeBtn.CustomizableEdges = customizableEdges3;
            WithdrawChequeBtn.DisabledState.BorderColor = Color.DarkGray;
            WithdrawChequeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            WithdrawChequeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            WithdrawChequeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            WithdrawChequeBtn.FillColor = Color.Teal;
            WithdrawChequeBtn.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            WithdrawChequeBtn.ForeColor = Color.White;
            WithdrawChequeBtn.Location = new Point(105, 546);
            WithdrawChequeBtn.Name = "WithdrawChequeBtn";
            WithdrawChequeBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            WithdrawChequeBtn.Size = new Size(235, 48);
            WithdrawChequeBtn.TabIndex = 11;
            WithdrawChequeBtn.Text = "Cheque";
            WithdrawChequeBtn.Click += WithdrawChequeBtn_Click;
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges5;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(105, 610);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 12;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // WithdrawSec
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(452, 760);
            Controls.Add(cancelBtn);
            Controls.Add(WithdrawChequeBtn);
            Controls.Add(WithdrawSavingsBtn);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "WithdrawSec";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "WithdrawSec";
            Load += WithdrawSec_Load;
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button WithdrawSavingsBtn;
        private Guna.UI2.WinForms.Guna2Button WithdrawChequeBtn;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}